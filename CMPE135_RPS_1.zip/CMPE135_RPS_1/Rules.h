/*
 * Rules.h
 *
 *  Created on: Sep 27, 2018
 *      Author: Sophia
 */

#ifndef RULES_H_
#define RULES_H_

//#include "Options.h"
//#include "Player.h"

class Rules{

protected:
	int faceOff (int one, int two);
};



#endif /* RULES_H_ */
