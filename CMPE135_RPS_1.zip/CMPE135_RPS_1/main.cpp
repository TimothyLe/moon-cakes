/*
 * main.cpp
 *
 *  Created on: Sep 26, 2018
 *      Author: Sophia
 */
#include "Display.h"
#include <string>
#include <iostream>

using namespace std;


int main(){
Display game1;
game1.iter1();

	return 0;
}


