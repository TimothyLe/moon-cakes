#include <iostream>
#include <string>
#include "InstrumentSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

InstrumentSpec::InstrumentSpec(map<string, Property *> *properties)
    : properties(properties)
{
}

map<string, Property *> *InstrumentSpec::get_properties() const
{
    return properties;
}

string InstrumentSpec::to_lower(string str)
{
    transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
}

bool InstrumentSpec::matches(InstrumentSpec *other_spec)
{
    map<string, Property *>::iterator it;

    for (it = properties->begin(); it != properties->end(); it++)
    {
        pair<string, Property *> p = *it;
        string key = p.first;
        Property *this_property = p.second;
        Property *other_property = (*other_spec->get_properties())[key];

        if (other_property != nullptr)
        {
            if (this_property->type != other_property->type) return false;
            if (this_property->type == ValueType::INTEGER)
            {
                if (this_property->ivalue != other_property->ivalue) return false;
            }
            else
            {
                if (this_property->svalue != other_property->svalue) return false;
            }
        }
    }

    return true;
}
