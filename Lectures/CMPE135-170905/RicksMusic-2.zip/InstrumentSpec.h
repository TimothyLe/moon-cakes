#ifndef INSTRUMENTSPEC_H_
#define INSTRUMENTSPEC_H_

#include <string>
#include <map>

using namespace std;

enum class ValueType
{
    INTEGER, STRING,
};

struct Property
{
    ValueType type;
    union
    {
        int ivalue;
        string svalue;
    };

    Property(int value) : type(ValueType::INTEGER), ivalue(value) {}

    Property(string value) : type(ValueType::STRING)
    {
        new (&this->svalue) string(value);
    }
};

class InstrumentSpec
{
public:
    InstrumentSpec(map<string, Property *> *properties);

    map<string, Property *> *get_properties() const;

    bool matches(InstrumentSpec *other_spec);

private:
    map<string, Property *> *properties;

    string to_lower(string str);
};
#endif /* INSTRUMENTSPEC_H_ */
