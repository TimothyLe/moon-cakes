#ifndef BUILDER_H_
#define BUILDER_H_

enum class Builder
{
    FENDER, MARTIN, GIBSON, COLLINGS, OLSON, RYAN, PRS, ANY,
};

#endif /* BUILDER_H_ */
