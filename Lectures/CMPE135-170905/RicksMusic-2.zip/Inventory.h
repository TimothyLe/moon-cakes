#ifndef INVENTORY_H_
#define INVENTORY_H_

#include <list>
#include "Instrument.h"

using namespace std;

class Inventory
{
private:
    list<Instrument *> inventory;

public:
    Inventory();

    void add_instrument(string serial_number, double price,
                        InstrumentSpec *spec);

    Instrument *get(string serial_number);
    list<Instrument *> search(InstrumentSpec *search_spec);
};

#endif /* INVENTORY_H_ */
