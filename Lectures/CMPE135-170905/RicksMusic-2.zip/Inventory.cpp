#include <iostream>
#include <list>
#include <map>
#include <algorithm>
#include "Inventory.h"

using namespace std;

Inventory::Inventory()
{
}

void Inventory::add_instrument(string serial_number, double price,
                               InstrumentSpec *spec)
{
    Instrument *instrument = new Instrument(serial_number, price, spec);
    inventory.push_back(instrument);
}

Instrument *Inventory::get(string serial_number)
{
    list<Instrument *>::iterator it;

    for (it = inventory.begin(); it != inventory.end(); it++)
    {
        Instrument *instrument = *it;
        if (instrument->get_serial_number() == serial_number) return instrument;
    }

    return nullptr;
}

list<Instrument *> Inventory::search(InstrumentSpec *search_spec)
{
    list<Instrument *> matching_instruments;
    list<Instrument *>::iterator it;

    for (it = inventory.begin(); it != inventory.end(); it++)
    {
        Instrument *instrument = *it;
        InstrumentSpec *instrument_spec = instrument->get_spec();

        if (instrument_spec->matches(search_spec))
        {
            matching_instruments.push_back(instrument);
        }
    }

    return matching_instruments;
}
