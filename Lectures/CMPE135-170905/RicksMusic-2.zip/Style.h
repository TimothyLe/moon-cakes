#ifndef STYLE_H_
#define STYLE_H_

enum class Style
{
    A, F,
};

#endif /* STYLE_H_ */
