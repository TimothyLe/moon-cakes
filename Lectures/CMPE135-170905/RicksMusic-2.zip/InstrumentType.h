#ifndef INSTRUMENTTYPE_H_
#define INSTRUMENTTYPE_H_

enum class InstrumentType
{
    GUITAR, BANJO, DOBRO, FIDDLE, BASS, MANDOLIN,
};

#endif /* INSTRUMENTTYPE_H_ */
