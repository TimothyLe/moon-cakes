#include <iostream>
#include <string>
#include <map>
#include "FindGuitarTester.h"
#include "Inventory.h"
#include "InstrumentType.h"
#include "Builder.h"
#include "Style.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

void FindGuitarTester::initialize_inventory(Inventory *inventory)
{
    map<string, Property *> *properties = new map<string, Property *>();
    (*properties)["instrumentType"] =
                        new Property((int) InstrumentType::GUITAR);
    (*properties)["builder"] = new Property((int) Builder::COLLINGS);
    (*properties)["model"] = new Property("CJ");
    (*properties)["numStrings"] = new Property(6);
    (*properties)["topWood"] = new Property((int) Wood::INDIAN_ROSEWOOD);
    (*properties)["backWood"] = new Property((int) Wood::SITKA);
    inventory->add_instrument("11277", 3999.95,
                              new InstrumentSpec(properties));

    properties = new map<string, Property *>();
    (*properties)["instrumentType"] =
                        new Property((int) InstrumentType::GUITAR);
    (*properties)["builder"] = new Property((int) Builder::MARTIN);
    (*properties)["model"] = new Property("D-18");
    (*properties)["topWood"] = new Property((int) Wood::MAHOGANY);
    (*properties)["backWood"] = new Property((int) Wood::ADIRONDACK);
    inventory->add_instrument("122784", 5495.95,
                              new InstrumentSpec(properties));

    properties = new map<string, Property *>();
    (*properties)["instrumentType"] =
                        new Property((int) InstrumentType::GUITAR);
    (*properties)["builder"] = new Property((int) Builder::FENDER);
    (*properties)["model"] = new Property("Stratocastor");
    (*properties)["type"] = new Property((int) Type::ELECTRIC);
    (*properties)["topWood"] = new Property((int) Wood::ALDER);
    (*properties)["backWood"] = new Property((int) Wood::ALDER);
    inventory->add_instrument("V95693", 1499.95,
                              new InstrumentSpec(properties));
    inventory->add_instrument("V9512", 1549.95,
                              new InstrumentSpec(properties));

    properties = new map<string, Property *>();
    (*properties)["instrumentType"] =
                        new Property((int) InstrumentType::GUITAR);
    (*properties)["builder"] = new Property((int) Builder::GIBSON);
    (*properties)["model"] = new Property("Les Paul");
    (*properties)["topWood"] = new Property((int) Wood::MAPLE);
    (*properties)["backWood"] = new Property((int) Wood::MAPLE);
    inventory->add_instrument("70108276", 2295.95,
                              new InstrumentSpec(properties));

    properties = new map<string, Property *>();
    (*properties)["instrumentType"] =
                        new Property((int) InstrumentType::GUITAR);
    (*properties)["model"] = new Property("SG '61 Reissue");
    (*properties)["topWood"] = new Property((int) Wood::MAHOGANY);
    (*properties)["backWood"] = new Property((int) Wood::MAHOGANY);
    inventory->add_instrument("82765501", 1890.95,
                              new InstrumentSpec(properties));

    properties = new map<string, Property *>();
    (*properties)["instrumentType"] =
                        new Property((int) InstrumentType::MANDOLIN);
    (*properties)["type"] = new Property((int) Type::ACOUSTIC);
    (*properties)["model"] = new Property("F-5G");
    (*properties)["backWood"] = new Property((int) Wood::MAPLE);
    (*properties)["topWood"] = new Property((int) Wood::MAPLE);
    inventory->add_instrument("9019920", 5495.99,
                              new InstrumentSpec(properties));

    properties = new map<string, Property *>();
    (*properties)["instrumentType"] =
                        new Property((int) InstrumentType::BANJO);
    (*properties)["model"] = new Property("RB-3 Wreath");
    (*properties)["numStrings"] = new Property(5);
    inventory->add_instrument("8900231", 2945.95,
                              new InstrumentSpec(properties));
}

ostream& operator << (ostream& ostr, const Builder builder)
{
    switch (builder)
    {
        case Builder::FENDER:   ostr << "Fender";   break;
        case Builder::MARTIN:   ostr << "Martin";   break;
        case Builder::GIBSON:   ostr << "Gibson";   break;
        case Builder::COLLINGS: ostr << "Collings"; break;
        case Builder::OLSON:    ostr << "Olson";    break;
        case Builder::RYAN:     ostr << "Ryan";     break;
        case Builder::PRS :     ostr << "PRS";      break;
        default:                ostr << "Unspecified";
    }
    return ostr;
}

ostream& operator << (ostream& ostr, const Type type)
{
    switch (type)
    {
        case Type::ACOUSTIC:    ostr << "acoustic"; break;
        case Type::ELECTRIC:    ostr << "electric"; break;
        default:                ostr << "unspecified";
    }
    return ostr;
}

ostream& operator << (ostream& ostr, const Wood wood)
{
    switch (wood)
    {
        case Wood::INDIAN_ROSEWOOD:     ostr << "Indian Rosewood";      break;
        case Wood::BRAZILIAN_ROSEWOOD:  ostr << "Brazilian Rosewood";   break;
        case Wood::MAHOGANY:            ostr << "Mahogany";             break;
        case Wood::MAPLE:               ostr << "Maple";                break;
        case Wood::COCOBOLO:            ostr << "Cocobolo";             break;
        case Wood::CEDAR:               ostr << "Cedar";                break;
        case Wood::ADIRONDACK:          ostr << "Adirondack";           break;
        case Wood::ALDER:               ostr << "Alder";                break;
        case Wood::SITKA:               ostr << "Sitka";                break;
        default:                        ostr << "unspecified";
    }
    return ostr;
}

ostream& operator << (ostream& ostr, const InstrumentType type)
{
    switch (type)
    {
        case InstrumentType::BANJO:    ostr << "banjo";    break;
        case InstrumentType::BASS :    ostr << "bass";     break;
        case InstrumentType::DOBRO:    ostr << "dobro";    break;
        case InstrumentType::FIDDLE:   ostr << "fiddle";   break;
        case InstrumentType::GUITAR:   ostr << "guitar";   break;
        case InstrumentType::MANDOLIN: ostr << "mandolin"; break;
    }
    return ostr;
}

int main()
{
    // Set up Rick's guitar inventory.
    Inventory *inventory = new Inventory();
    FindGuitarTester::initialize_inventory(inventory);

    map<string, Property *> *properties = new map<string, Property *>();
    (*properties)["builder"] = new Property((int) Builder::GIBSON);
    (*properties)["backWood"] = new Property((int) Wood::MAPLE);
    InstrumentSpec *target = new InstrumentSpec(properties);

    list<Instrument *> matching_instruments = inventory->search(target);
    if (matching_instruments.size() > 0)
    {
        list<Instrument *>::iterator it_instrument;
        for (it_instrument  = matching_instruments.begin();
             it_instrument != matching_instruments.end();
             it_instrument++)
        {
            Instrument *instrument = *it_instrument;
            InstrumentSpec *spec = instrument->get_spec();
            map<string, Property *> *properties = spec->get_properties();
            int instrument_type = (*properties)["instrumentType"]->ivalue;

            cout << "We have a matching "
                 << (InstrumentType) instrument_type << endl;
            cout << "serial number " << instrument->get_serial_number() << endl;
            cout << "for $" << instrument->get_price() << endl << endl;
        }
    }
    else
    {
        cout << "Sorry, we have nothing that matches." << endl;
    }
}
