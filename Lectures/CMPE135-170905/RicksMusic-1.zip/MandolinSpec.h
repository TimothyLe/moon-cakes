#ifndef MANDOLINSPEC_H_
#define MANDOLINSPEC_H_

#include <string>
#include "InstrumentSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"
#include "Style.h"

using namespace std;

class MandolinSpec : public InstrumentSpec
{
public:
    MandolinSpec(Builder builder, string model, Type type,
                 Style style, Wood back_wood, Wood top_wood);

    Style get_style() const;
    bool matches(InstrumentSpec *other_spec);

private:
    Style style;
};

#endif /* MANDOLINSPEC_H_ */
