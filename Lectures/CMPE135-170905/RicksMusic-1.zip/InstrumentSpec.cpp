#include <string>
#include "InstrumentSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

InstrumentSpec::InstrumentSpec(Builder builder, string model, Type type,
                               Wood back_wood, Wood top_wood)
    : model(model), builder(builder), type(type),
      back_wood(back_wood), top_wood(top_wood)
{
}

Builder InstrumentSpec::get_builder() const { return builder; }
string  InstrumentSpec::get_model() const { return model; }
Type    InstrumentSpec::get_type() const { return type; }
Wood    InstrumentSpec::get_back_wood() const { return back_wood; }
Wood    InstrumentSpec::get_top_wood() const { return top_wood; }

string InstrumentSpec::to_lower(string str)
{
    transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
}

bool InstrumentSpec::matches(InstrumentSpec *other_spec)
{
    if (builder != other_spec->builder) return false;
    if (   (model != "")
        && (to_lower(model) != to_lower(other_spec->model))) return false;
    if (type != other_spec->type) return false;
    if (back_wood != other_spec->back_wood) return false;
    if (top_wood != other_spec->top_wood) return false;
    return true;
}
