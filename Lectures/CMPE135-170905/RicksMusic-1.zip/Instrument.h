#ifndef INSTRUMENT_H_
#define INSTRUMENT_H_

#include <string>
#include "InstrumentSpec.h"

using namespace std;

class Instrument
{
private:
    string serial_number, model;
    double price;
    InstrumentSpec *spec;

public:
    Instrument(string serial_number, double price, InstrumentSpec *spec);

    string get_serial_number() const;
    double get_price() const;
    void   set_price(float new_price);
    InstrumentSpec *get_spec() const;
};

#endif /* INSTRUMENT_H_ */
