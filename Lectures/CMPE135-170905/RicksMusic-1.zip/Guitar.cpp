#include <string>
#include "Guitar.h"
#include "GuitarSpec.h"
#include "InstrumentSpec.h"

using namespace std;

Guitar::Guitar(string serial_number, double price, GuitarSpec *spec)
    : Instrument(serial_number, price, spec)
{
}
