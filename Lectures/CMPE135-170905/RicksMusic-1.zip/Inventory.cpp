#include <list>
#include <algorithm>
#include "Inventory.h"
#include "Guitar.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

Inventory::Inventory()
{
}

void Inventory::add_instrument(string serial_number, double price,
                               InstrumentSpec *spec)
{
    Instrument *instrument = nullptr;

    if (typeid(spec) == typeid(GuitarSpec))
    {
        instrument = new Guitar(serial_number, price,
                                static_cast<GuitarSpec *>(spec));
    }
    else if (typeid(spec) == typeid(MandolinSpec))
    {
        instrument = new Mandolin(serial_number, price,
                                  static_cast<MandolinSpec *>(spec));
    }

    inventory.push_back(instrument);

}

Instrument *Inventory::get(string serial_number)
{
    list<Instrument *>::iterator it;

    for (it = inventory.begin(); it != inventory.end(); it++)
    {
        Instrument *instrument = *it;
        if (instrument->get_serial_number() == serial_number) return instrument;
    }

    return nullptr;
}

list<Guitar *> Inventory::search(GuitarSpec *search_spec)
{
    list<Guitar *> matching_guitars;
    list<Instrument *>::iterator it;

    for (it = inventory.begin(); it != inventory.end(); it++)
    {
        Guitar *guitar = static_cast<Guitar *>(*it);
        GuitarSpec *guitar_spec =
                        static_cast<GuitarSpec *>(guitar->get_spec());

        if (guitar_spec->matches(search_spec))
        {
            matching_guitars.push_back(guitar);
        }
    }

    return matching_guitars;
}

list<Mandolin *> Inventory::search(MandolinSpec *search_spec)
{
    list<Mandolin *> matching_mandolins;
    list<Instrument *>::iterator it;

    for (it = inventory.begin(); it != inventory.end(); it++)
    {
        Mandolin *mandolin = static_cast<Mandolin *>(*it);
        MandolinSpec *mandolin_spec =
                        static_cast<MandolinSpec *>(mandolin->get_spec());

        if (mandolin_spec->matches(search_spec))
        {
            matching_mandolins.push_back(mandolin);
        }
    }

    return matching_mandolins;
}
