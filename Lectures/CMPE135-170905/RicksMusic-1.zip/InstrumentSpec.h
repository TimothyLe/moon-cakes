#ifndef INSTRUMENTSPEC_H_
#define INSTRUMENTSPEC_H_

#include <string>
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

class InstrumentSpec
{
public:
    InstrumentSpec(Builder builder, string model, Type type,
                   Wood back_wood, Wood top_wood);

    Builder get_builder() const;
    string  get_model() const;
    Type    get_type() const;
    Wood    get_back_wood() const;
    Wood    get_top_wood() const;

    bool matches(InstrumentSpec *other_spec);

private:
    string model;
    Builder builder;
    Type type;
    Wood back_wood, top_wood;

    string to_lower(string str);
};
#endif /* INSTRUMENTSPEC_H_ */
