#ifndef GUITARSPEC_H_
#define GUITARSPEC_H_

#include <string>
#include "InstrumentSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

class GuitarSpec : public InstrumentSpec
{
public:
    GuitarSpec(Builder builder, string model, Type type,
               int string_count, Wood back_wood, Wood top_wood);

    int get_string_count() const;
    bool matches(InstrumentSpec *other_spec);

private:
    int string_count;
};

#endif /* GUITARSPEC_H_ */
