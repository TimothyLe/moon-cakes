#include <string>
#include "MandolinSpec.h"
#include "InstrumentSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

MandolinSpec::MandolinSpec(Builder builder, string model, Type type,
                           Style style, Wood back_wood, Wood top_wood)
    : InstrumentSpec(builder, model, type, back_wood, top_wood),
      style(style)
{
}

Style MandolinSpec::get_style() const { return style; }

bool MandolinSpec::matches(InstrumentSpec *other_spec)
{
    if (!InstrumentSpec::matches(other_spec)) return false;
    if (typeid(other_spec) != typeid(MandolinSpec)) return false;

    MandolinSpec *mandolin_spec = static_cast<MandolinSpec *>(other_spec);
    if (style != mandolin_spec->style) return false;

    return true;
}
