#include <string>
#include "GuitarSpec.h"
#include "InstrumentSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

GuitarSpec::GuitarSpec(Builder builder, string model, Type type,
                       int string_count, Wood back_wood, Wood top_wood)
    : InstrumentSpec(builder, model, type, back_wood, top_wood),
      string_count(string_count)
{
}

int GuitarSpec::get_string_count() const { return string_count; }

bool GuitarSpec::matches(InstrumentSpec *other_spec)
{
    if (!InstrumentSpec::matches(other_spec)) return false;
    if (typeid(other_spec) != typeid(GuitarSpec)) return false;

    GuitarSpec *guitar_spec = static_cast<GuitarSpec *>(other_spec);
    if (string_count != guitar_spec->string_count) return false;

    return true;
}
