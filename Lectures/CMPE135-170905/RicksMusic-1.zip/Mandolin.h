#ifndef MANDOLIN_H_
#define MANDOLIN_H_

#include <string>
#include "Instrument.h"
#include "MandolinSpec.h"

using namespace std;

class Mandolin : public Instrument
{
public:
    Mandolin(string serial_number, double price, MandolinSpec *spec);
};

#endif /* MANDOLIN_H_ */
