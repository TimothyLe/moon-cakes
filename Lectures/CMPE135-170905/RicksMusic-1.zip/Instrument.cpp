#include "Instrument.h"

using namespace std;

Instrument::Instrument(string serial_number, double price, InstrumentSpec *spec)
    : serial_number(serial_number), price(price), spec(spec)
{
}

string Instrument::get_serial_number() const { return serial_number; }
double Instrument::get_price() const { return price; }
void   Instrument::set_price(float new_price) { price = new_price; }
InstrumentSpec *Instrument::get_spec() const { return spec; }
