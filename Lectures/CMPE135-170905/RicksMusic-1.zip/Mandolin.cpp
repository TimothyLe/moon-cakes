#include <string>
#include "Mandolin.h"
#include "MandolinSpec.h"
#include "InstrumentSpec.h"

using namespace std;

Mandolin::Mandolin(string serial_number, double price, MandolinSpec *spec)
    : Instrument(serial_number, price, spec)
{
}
