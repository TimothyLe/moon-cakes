#ifndef GUITAR_H_
#define GUITAR_H_

#include <string>
#include "Instrument.h"
#include "GuitarSpec.h"

using namespace std;

class Guitar : public Instrument
{
public:
    Guitar(string serial_number, double price, GuitarSpec *spec);
};

#endif /* GUITAR_H_ */
