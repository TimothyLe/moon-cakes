#ifndef INVENTORY_H_
#define INVENTORY_H_

#include <list>
#include "Instrument.h"
#include "Guitar.h"
#include "GuitarSpec.h"
#include "Mandolin.h"
#include "MandolinSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

class Inventory
{
private:
    list<Instrument *> inventory;

public:
    Inventory();

    void add_instrument(string serial_number, double price,
                        InstrumentSpec *spec);

    Instrument *get(string serial_number);
    list<Guitar *>   search(GuitarSpec   *search_spec);
    list<Mandolin *> search(MandolinSpec *search_spec);
};

#endif /* INVENTORY_H_ */
