#include <list>
#include <algorithm>
#include "Inventory.h"
#include "Guitar.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

Inventory::Inventory()
{
}

void Inventory::add_guitar(string serial_number, double price,
                           Builder builder, string model, Type type,
                           Wood back_wood, Wood top_wood)
{
    Guitar *guitar = new Guitar(serial_number, price, builder,
                               model, type, back_wood, top_wood);
    guitars.push_back(guitar);
}

Guitar *Inventory::get_guitar(string serial_number)
{
    list<Guitar *>::iterator it;

    for (it = guitars.begin(); it != guitars.end(); it++)
    {
        Guitar *guitar = *it;
        if (guitar->get_serial_number() == serial_number) return guitar;
    }

    return nullptr;
}

string Inventory::to_lower(string str)
{
    transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
}

list<Guitar *> Inventory::search(GuitarSpec *search_spec)
{
    list<Guitar *> matching_guitars;
    list<Guitar *>::iterator it;

    for (it = guitars.begin(); it != guitars.end(); it++)
    {
        Guitar *guitar = *it;
        GuitarSpec *guitar_spec = guitar->get_spec();

        // Ignore serial number since that's unique.
        // Ignore price since that's unique.

        Builder builder = search_spec->get_builder();
        if (builder != guitar_spec->get_builder()) continue;

        string model = to_lower(search_spec->get_model());
        if (   (model != "")
            && (model != to_lower(guitar_spec->get_model()))) continue;

        Type type = search_spec->get_type();
        if (type != guitar_spec->get_type()) continue;

        Wood back_wood = search_spec->get_back_wood();
        if (back_wood!= guitar_spec->get_back_wood()) continue;

        Wood top_wood = search_spec->get_top_wood();
        if (top_wood != guitar_spec->get_top_wood()) continue;

        matching_guitars.push_back(guitar);
    }

    return matching_guitars;
}
