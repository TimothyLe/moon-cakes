#ifndef GUITAR_H_
#define GUITAR_H_

#include <string>
#include "GuitarSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

class Guitar
{
private:
    string serial_number, model;
    double price;
    GuitarSpec *spec;

public:
    Guitar(string serial_number, double price,
           Builder builder, string model, Type type,
           Wood back_wood, Wood top_wood);

    string get_serial_number() const;
    double get_price() const;
    void   set_price(float new_price);
    GuitarSpec *get_spec() const;
};

#endif /* GUITAR_H_ */
