#include <string>
#include "Guitar.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

Guitar::Guitar(string serial_number, double price,
               Builder builder, string model, Type type,
               Wood back_wood, Wood top_wood)
    : serial_number(serial_number), price(price),
      spec(new GuitarSpec(builder, model, type, back_wood, top_wood))
{
}

string Guitar::get_serial_number() const { return serial_number; }
double Guitar::get_price() const { return price; }
void   Guitar::set_price(float new_price) { price = new_price; }
GuitarSpec *Guitar::get_spec() const { return spec; }
