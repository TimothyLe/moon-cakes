#ifndef INVENTORY_H_
#define INVENTORY_H_

#include <list>
#include "Guitar.h"
#include "GuitarSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

class Inventory
{
public:
    Inventory();

    void add_guitar(string serial_number, double price,
                    Builder builder, string model, Type type,
                    Wood back_wood, Wood top_wood);

    Guitar *get_guitar(string serial_number);
    list<Guitar *> search(GuitarSpec *search_spec);

private:
    list<Guitar *> guitars;

    string to_lower(string str);
};

#endif /* INVENTORY_H_ */
