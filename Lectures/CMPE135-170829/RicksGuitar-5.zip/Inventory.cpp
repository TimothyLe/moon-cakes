#include <list>
#include <algorithm>
#include "Inventory.h"
#include "Guitar.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

Inventory::Inventory()
{
}

void Inventory::add_guitar(string serial_number, double price,
                           Builder builder, string model, Type type,
                           int string_count, Wood back_wood, Wood top_wood)
{
    Guitar *guitar = new Guitar(serial_number, price, builder, model,
                                type, string_count, back_wood, top_wood);
    guitars.push_back(guitar);
}

Guitar *Inventory::get_guitar(string serial_number)
{
    list<Guitar *>::iterator it;

    for (it = guitars.begin(); it != guitars.end(); it++)
    {
        Guitar *guitar = *it;
        if (guitar->get_serial_number() == serial_number) return guitar;
    }

    return nullptr;
}

list<Guitar *> Inventory::search(GuitarSpec *search_spec)
{
    list<Guitar *> matching_guitars;
    list<Guitar *>::iterator it;

    for (it = guitars.begin(); it != guitars.end(); it++)
    {
        Guitar *guitar = *it;
        GuitarSpec *guitar_spec = guitar->get_spec();

        if (guitar_spec->matches(search_spec))
        {
            matching_guitars.push_back(guitar);
        }
    }

    return matching_guitars;
}
