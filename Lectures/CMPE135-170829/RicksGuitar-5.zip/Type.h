#ifndef TYPE_H_
#define TYPE_H_

enum class Type
{
    ACOUSTIC, ELECTRIC
};

#endif /* TYPE_H_ */
