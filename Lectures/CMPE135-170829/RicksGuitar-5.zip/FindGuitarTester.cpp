#include <iostream>
#include <string>
#include "FindGuitarTester.h"
#include "Guitar.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

void FindGuitarTester::initialize_inventory(Inventory *inventory)
{
    inventory->add_guitar("11277", 3999.95, Builder::COLLINGS,
                          "CJ", Type::ACOUSTIC, 6,
                          Wood::INDIAN_ROSEWOOD, Wood::SITKA);
    inventory->add_guitar("V95693", 1499.95, Builder::FENDER,
                          "Stratocastor", Type::ELECTRIC, 6,
                          Wood::ALDER, Wood::ALDER);
    inventory->add_guitar("V9512", 1549.95, Builder::FENDER,
                          "Stratocastor", Type::ELECTRIC, 6,
                          Wood::ALDER, Wood::ALDER);
    inventory->add_guitar("122784", 5495.95, Builder::MARTIN,
                          "D-18", Type::ACOUSTIC, 8,
                          Wood::MAHOGANY, Wood::ADIRONDACK);
    inventory->add_guitar("76531", 6295.95, Builder::MARTIN,
                          "OM-28", Type::ACOUSTIC, 6,
                          Wood::BRAZILIAN_ROSEWOOD, Wood::ADIRONDACK);
    inventory->add_guitar("70108276", 2295.95, Builder::GIBSON,
                          "Les Paul", Type::ELECTRIC, 8,
                          Wood::MAHOGANY, Wood::MAPLE);
    inventory->add_guitar("82765501", 1890.95, Builder::GIBSON,
                          "SG '61 Reissue", Type::ELECTRIC, 6,
                          Wood::MAHOGANY, Wood::MAHOGANY);
    inventory->add_guitar("77023", 6275.95, Builder::MARTIN,
                          "D-28", Type::ACOUSTIC, 12,
                          Wood::BRAZILIAN_ROSEWOOD, Wood::ADIRONDACK);
    inventory->add_guitar("1092", 12995.95, Builder::OLSON,
                          "SJ", Type::ACOUSTIC, 6,
                          Wood::BRAZILIAN_ROSEWOOD, Wood::CEDAR);
    inventory->add_guitar("566-62", 8999.95, Builder::RYAN,
                          "Cathedral", Type::ACOUSTIC, 6,
                          Wood::COCOBOLO, Wood::CEDAR);
    inventory->add_guitar("6 29584", 2100.95, Builder::PRS,
                          "Dave Navarro Signature", Type::ELECTRIC, 8,
                          Wood::MAHOGANY, Wood::MAPLE);
}

ostream& operator << (ostream& ostr, const Builder builder)
{
    switch (builder)
    {
        case Builder::FENDER:   ostr << "Fender";   break;
        case Builder::MARTIN:   ostr << "Martin";   break;
        case Builder::GIBSON:   ostr << "Gibson";   break;
        case Builder::COLLINGS: ostr << "Collings"; break;
        case Builder::OLSON:    ostr << "Olson";    break;
        case Builder::RYAN:     ostr << "Ryan";     break;
        case Builder::PRS :     ostr << "PRS";      break;
        default:                ostr << "Unspecified";
    }
    return ostr;
}

ostream& operator << (ostream& ostr, const Type type)
{
    switch (type)
    {
        case Type::ACOUSTIC:    ostr << "acoustic"; break;
        case Type::ELECTRIC:    ostr << "electric"; break;
        default:                ostr << "unspecified";
    }
    return ostr;
}

ostream& operator << (ostream& ostr, const Wood wood)
{
    switch (wood)
    {
        case Wood::INDIAN_ROSEWOOD:     ostr << "Indian Rosewood";      break;
        case Wood::BRAZILIAN_ROSEWOOD:  ostr << "Brazilian Rosewood";   break;
        case Wood::MAHOGANY:            ostr << "Mahogany";             break;
        case Wood::MAPLE:               ostr << "Maple";                break;
        case Wood::COCOBOLO:            ostr << "Cocobolo";             break;
        case Wood::CEDAR:               ostr << "Cedar";                break;
        case Wood::ADIRONDACK:          ostr << "Adirondack";           break;
        case Wood::ALDER:               ostr << "Alder";                break;
        case Wood::SITKA:               ostr << "Sitka";                break;
        default:                        ostr << "unspecified";
    }
    return ostr;
}

int main()
{
    // Set up Rick's guitar inventory.
    Inventory *inventory = new Inventory();
    FindGuitarTester::initialize_inventory(inventory);

    GuitarSpec *what_erin_likes =
        new GuitarSpec(Builder::FENDER, "stratocastor",
                       Type::ELECTRIC, 6, Wood::ALDER, Wood::ALDER);
    list<Guitar *> matching_guitars = inventory->search(what_erin_likes);

    if (matching_guitars.size() > 0)
    {
        cout << "Erin, you might like these guitars:" << endl;
        list<Guitar *>::iterator it;
        for (it = matching_guitars.begin(); it != matching_guitars.end(); it++)
        {
            Guitar *guitar = *it;
            GuitarSpec *spec = guitar->get_spec();
            cout << spec->get_builder() << " "
                 << spec->get_model() << " "
                 << spec->get_type() << " guitar:\n   "
                 << spec->get_back_wood() << " back and sides,\n   "
                 << spec->get_top_wood() << " top.\nYou can have it for only $"
                 << guitar->get_price() << "!" << endl;
            cout << "  ----" << endl;
        }
    }
    else
    {
        cout << "Sorry, Erin, we have nothing for you.";
    }
}
