#ifndef GUITAR_H_
#define GUITAR_H_

#include <string>
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

class Guitar
{
private:
    string serial_number, model;
    double price;
    Builder builder;
    Type type;
    Wood back_wood, top_wood;

public:
    Guitar(string serial_number, double price,
           Builder builder, string model, Type type,
           Wood back_wood, Wood top_wood);

    string  get_serial_number() const;
    double  get_price() const;
    void    set_price(float new_price);
    Builder get_builder() const;
    string  get_model() const;
    Type    get_type() const;
    Wood    get_back_wood() const;
    Wood    get_top_wood() const;
};

#endif /* GUITAR_H_ */
