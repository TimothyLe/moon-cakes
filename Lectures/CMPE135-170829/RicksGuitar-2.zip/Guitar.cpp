#include <string>
#include "Guitar.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

Guitar::Guitar(string serial_number, double price,
               Builder builder, string model, Type type,
               Wood back_wood, Wood top_wood)
    : serial_number(serial_number), model(model), price(price),
      builder(builder), type(type), back_wood(back_wood), top_wood(top_wood)
{
}

string  Guitar::get_serial_number() const { return serial_number; }
double  Guitar::get_price() const { return price; }
void    Guitar::set_price(float new_price) { price = new_price; }
Builder Guitar::get_builder() const { return builder; }
string  Guitar::get_model() const { return model; }
Type    Guitar::get_type() const { return type; }
Wood    Guitar::get_back_wood() const { return back_wood; }
Wood    Guitar::get_top_wood() const { return top_wood; }
