#ifndef GUITARSPEC_H_
#define GUITARSPEC_H_

#include <string>
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

class GuitarSpec
{
private:
    string model;
    Builder builder;
    Type type;
    int string_count;
    Wood back_wood, top_wood;

public:
    GuitarSpec(Builder builder, string model, Type type,
               int string_count, Wood back_wood, Wood top_wood);

    Builder get_builder() const;
    string  get_model() const;
    Type    get_type() const;
    int     get_string_count() const;
    Wood    get_back_wood() const;
    Wood    get_top_wood() const;
};

#endif /* GUITARSPEC_H_ */
