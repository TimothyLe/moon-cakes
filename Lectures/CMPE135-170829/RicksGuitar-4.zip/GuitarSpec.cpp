#include <string>
#include "GuitarSpec.h"
#include "Builder.h"
#include "Type.h"
#include "Wood.h"

using namespace std;

GuitarSpec::GuitarSpec(Builder builder, string model, Type type,
                       int string_count, Wood back_wood, Wood top_wood)
    : model(model), builder(builder), type(type), string_count(string_count),
      back_wood(back_wood), top_wood(top_wood)
{
}

Builder GuitarSpec::get_builder() const { return builder; }
string  GuitarSpec::get_model() const { return model; }
Type    GuitarSpec::get_type() const { return type; }
int     GuitarSpec::get_string_count() const { return string_count; }
Wood    GuitarSpec::get_back_wood() const { return back_wood; }
Wood    GuitarSpec::get_top_wood() const { return top_wood; }
