#include <list>
#include "Inventory.h"
#include "Guitar.h"

using namespace std;

Inventory::Inventory()
{
}

void Inventory::add_guitar(string serial_number, double price,
                           string builder, string model, string type,
                           string back_wood, string top_wood)
{
    Guitar *guitar = new Guitar(serial_number, price, builder,
                               model, type, back_wood, top_wood);
    guitars.push_back(guitar);
}

Guitar *Inventory::get_guitar(string serial_number)
{
    list<Guitar *>::iterator it;

    for (it = guitars.begin(); it != guitars.end(); it++)
    {
        Guitar *guitar = *it;
        if (guitar->get_serial_number() == serial_number) return guitar;
    }

    return nullptr;
}

Guitar *Inventory::search(Guitar *search_guitar)
{
    list<Guitar *>::iterator it;

    for (it = guitars.begin(); it != guitars.end(); it++)
    {
        Guitar *guitar = *it;

        // Ignore serial number since that's unique.
        // Ignore price since that's unique.

        string builder = search_guitar->get_builder();
        if (builder != guitar->get_builder())  continue;

        string model = search_guitar->get_model();
        if (model != guitar->get_model()) continue;

        string type = search_guitar->get_type();
        if (type != guitar->get_type()) continue;

        string back_wood = search_guitar->get_back_wood();
        if (back_wood!= guitar->get_back_wood()) continue;

        string top_wood = search_guitar->get_top_wood();
        if (top_wood != guitar->get_top_wood()) continue;

        return *it;
    }

    return nullptr;
}
