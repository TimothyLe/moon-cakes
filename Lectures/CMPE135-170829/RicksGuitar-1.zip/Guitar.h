#ifndef GUITAR_H_
#define GUITAR_H_

#include <string>

using namespace std;

class Guitar
{
private:
    string serial_number, builder, model, type, back_wood, top_wood;
    double price;

public:
    Guitar(string serial_number, double price,
           string builder, string model, string type,
           string back_wood, string top_wood);

    string get_serial_number() const;
    double get_price() const;
    void   set_price(float new_price);
    string get_builder() const;
    string get_model() const;
    string get_type() const;
    string get_back_wood() const;
    string get_top_wood() const;
};

#endif /* GUITAR_H_ */
