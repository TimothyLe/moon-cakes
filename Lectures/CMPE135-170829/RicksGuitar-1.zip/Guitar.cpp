#include <string>
#include "Guitar.h"

using namespace std;

Guitar::Guitar(string serial_number, double price,
               string builder, string model, string type,
               string back_wood, string top_wood)
    : serial_number(serial_number), builder(builder), model(model),
      type(type), back_wood(back_wood), top_wood(top_wood), price(price)
{
}

string Guitar::get_serial_number() const { return serial_number; }
double Guitar::get_price() const { return price; }
void   Guitar::set_price(float new_price) { price = new_price; }
string Guitar::get_builder() const { return builder; }
string Guitar::get_model() const { return model; }
string Guitar::get_type() const { return type; }
string Guitar::get_back_wood() const { return back_wood; }
string Guitar::get_top_wood() const { return top_wood; }
