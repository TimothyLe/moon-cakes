#ifndef INVENTORY_H_
#define INVENTORY_H_

#include <list>
#include "Guitar.h"

using namespace std;

class Inventory
{
private:
    list<Guitar *> guitars;

public:
    Inventory();

    void add_guitar(string serial_number, double price,
                    string builder, string model, string type,
                    string back_wood, string top_wood);

    Guitar *get_guitar(string serial_number);
    Guitar *search(Guitar *search_guitar);
};

#endif /* INVENTORY_H_ */
