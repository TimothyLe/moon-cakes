#ifndef FINDGUITARTESTER_H_
#define FINDGUITARTESTER_H_

#include "Inventory.h"

using namespace std;

class FindGuitarTester
{
public:
    static void initialize_inventory(Inventory *inventory);
};

#endif /* FINDGUITARTESTER_H_ */
