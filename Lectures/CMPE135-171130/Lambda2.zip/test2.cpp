#include <iostream>
#include <vector>
#include "Person.h"

vector<Person> init()
{
    vector<Person> v;
    v.push_back(Person("Ron", "Mak", Gender::M));
    v.push_back(Person("Marie", "Curie", Gender::F));
    v.push_back(Person("Agatha", "Cristie", Gender::F));
    v.push_back(Person("Barack", "Obama", Gender::M));
    return v;
}

ostream& operator <<(ostream& outs, Person &p)
{
    outs << "  {" << "first=" << p.first << ", last=" << p.last
         << ", gender=" << (p.gender == Gender::F ? "F" : "M") << "}";
    return outs;
}

vector<Person> match(const vector<Person> people, bool f(const Person &p))
{
    vector<Person> matches;
    for (const Person& p : people) if (f(p)) matches.push_back(p);
    return matches;
}

int main()
{
    vector<Person> people = init();
    vector<Person> males;
    vector<Person> cs;

    cout << "Males:" << endl;
    males = match(people, [] (const Person &p) -> bool
                          {
                              return p.gender == Gender::M;
                          });
    for (Person& p : males) cout << p << endl;

    cout << endl << "Last name starts with C:" << endl;
    cs = match(people, [] (const Person &p) -> bool
                       {
                           return p.last[0] == 'C';
                       });
    for (Person& p : cs) cout << p << endl;
}
