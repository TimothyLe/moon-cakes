#include <iostream>
#include <vector>
#include "Person.h"

vector<Person> init()
{
    vector<Person> v;
    v.push_back(Person("Ron", "Mak", Gender::M));
    v.push_back(Person("Marie", "Curie", Gender::F));
    v.push_back(Person("Agatha", "Cristie", Gender::F));
    v.push_back(Person("Barack", "Obama", Gender::M));
    return v;
}

ostream& operator <<(ostream& outs, Person &p)
{
    outs << "  {" << "first=" << p.first << ", last=" << p.last
         << ", gender=" << (p.gender == Gender::F ? "F" : "M") << "}";
    return outs;
}

bool is_male(const Person &p)
{
    return p.gender == Gender::M;
}

bool is_C(const Person &p)
{
    return p.last[0] == 'C';
}

vector<Person> match(const vector<Person> people, bool f(const Person &p))
{
    vector<Person> matches;
    for (const Person& p : people) if (f(p)) matches.push_back(p);
    return matches;
}

int main()
{
    vector<Person> people = init();
    vector<Person> males;
    vector<Person> cs;

    cout << "Males:" << endl;
    males = match(people, is_male);
    for (Person& p : males) cout << p << endl;

    cout << endl << "Last name starts with C:" << endl;
    cs = match(people, is_C);
    for (Person& p : cs) cout << p << endl;
}
