#include "Person.h"
#include <string>

Person::Person(string f, string l, Gender g)
    : first(f), last(l), gender(g)
{
}

Person::~Person()
{
}
