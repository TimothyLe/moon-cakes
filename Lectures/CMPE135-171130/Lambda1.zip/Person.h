#ifndef PERSON_H_
#define PERSON_H_

#include <string>

using namespace std;

enum class Gender { M, F };

class Person
{
public:
    Person(string f, string l, Gender g);
    virtual ~Person();

    string first;
    string last;
    Gender gender;
};

#endif /* PERSON_H_ */
