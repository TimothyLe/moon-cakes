//
//  Human.cpp
//  RPSAssignments135
//
//  Created by Michael Ong on 10/5/18.
//  Copyright © 2018 CMPE135. All rights reserved.
//

#include "Human.hpp"
#include "Player.hpp"
#include "Computer.hpp"

Human::Human() :Player(){
    
}
