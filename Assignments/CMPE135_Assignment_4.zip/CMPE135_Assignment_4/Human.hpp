//
//  Human.hpp
//  RPSAssignments135
//
//  Created by Michael Ong on 10/5/18.
//  Copyright © 2018 CMPE135. All rights reserved.
//

#ifndef Human_hpp
#define Human_hpp

#include <iostream>
#include "Player.hpp"

class Human : public Player{
public:
    Human();
};

#endif /* Human_hpp */
