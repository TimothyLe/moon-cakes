#include "Computer.hpp"

Computer::Computer() : Player(
    score = 0,
    id = 0,
    wins = 0,
    losses = 0,
    ties = 0,
    name = "Default",
    choice = "None" // Choices can be Rock, Paper, Scissors, or None
)
{
    Player P;
}

Computer::~Computer()
{
}

int     Computer::randomChoice()
{
    
}

void    Computer::setPreviousChoice()
{

}

void    Computer::setPreviousSuccess()
{

}

int     Computer::getPreviousChoice()
{

}

bool    Computer::getPreviousSuccess()
{

}
