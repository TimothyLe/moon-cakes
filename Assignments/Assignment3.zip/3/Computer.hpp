#ifndef COMPUTER_H
#define COMPUTER_H

#include <iostream>
#include <stdio.h>
#include <string>
#include <stdbool.h>
#include "Player.hpp"

class Computer :  public Player
{
    public:
        Computer();
        ~Computer();
        int randomChoice();
        void setPreviousChoice();
        void setPreviousSuccess();
        int getPreviousChoice();
        bool getPreviousSuccess();

    private:
        int previousChoice;
        bool previousSuccess;
};
#endif 